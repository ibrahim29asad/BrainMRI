package com.example.BrainMRI_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrainMriBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrainMriBackendApplication.class, args);
	}

}
