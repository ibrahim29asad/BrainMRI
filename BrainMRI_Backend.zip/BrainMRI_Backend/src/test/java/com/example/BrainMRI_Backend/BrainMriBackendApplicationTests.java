package com.example.BrainMRI_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrainMriBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
